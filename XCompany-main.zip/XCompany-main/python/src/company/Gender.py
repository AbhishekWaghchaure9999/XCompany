import enum

class Gender(enum.Enum):
    MALE = "MALE"
    FEMALE = "FEMALE"